/**
 * This package contains interfaces and classes for the observer pattern implementation in the game.
 */
package game.observer;