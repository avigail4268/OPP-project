package game.gui;

import javax.swing.*;

public class CellButton extends JFrame {
    public CellButton() {
        super("Cell Button");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

    }
}
