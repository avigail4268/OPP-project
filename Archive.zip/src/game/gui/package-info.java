/**
 * This package contains the graphical user interface (GUI) classes for the game.
 */
package game.gui;