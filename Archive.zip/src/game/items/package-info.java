/**
 * Includes all the game items such as potions, power potions, treasure and walls.
 * Items implement interaction logic and affect players during the game.
 */
package game.items;