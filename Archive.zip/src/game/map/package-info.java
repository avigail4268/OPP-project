/**
 * This package manages the game's map and environment structure.
 * for characters and items position and on the map.
 * </p>
 */
package game.map;