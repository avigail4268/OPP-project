/**
 * This package contains classes and interfaces for handling audio in the game.
 */

package game.audio;