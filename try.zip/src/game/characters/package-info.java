
/**
 * This package contains all character-related classes for the game.
 * This package defines the players and the enemies such as Warrior, Mage, Archer, and enemies like Goblin, Orc, and Dragon.
 */
package game.characters;
